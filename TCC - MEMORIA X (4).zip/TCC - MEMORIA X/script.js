const btnIniciar = document.getElementById("btnIniciar");
const telaInicial = document.getElementById("tela-inicial");
const telaJogo = document.getElementById("tela-jogo");
const board = document.getElementById('board');
const levelSelect = document.getElementById('nivel');
const restartBtn = document.getElementById('btnReiniciar');
const btnVoltar = document.getElementById('btnVoltar');

const LEVELS = {
  facil: { pairs: 4, columns: 4 },
  medio: { pairs: 8, columns: 4 },
  dificil: { pairs: 12, columns: 6 }
};

let firstCard = null;
let secondCard = null;
let lock = false;

btnIniciar.addEventListener("click", () => {
  telaInicial.classList.remove("show");
  telaInicial.classList.add("hide");
  setTimeout(() => {
    telaJogo.classList.remove("hide");
    telaJogo.classList.add("show");
    startGame();
  }, 300);
});

btnVoltar.addEventListener("click", () => {
  telaJogo.classList.remove("show");
  telaJogo.classList.add("hide");
  setTimeout(() => {
    telaInicial.classList.remove("hide");
    telaInicial.classList.add("show");
  }, 300);
});


function startGame() {
  const level = levelSelect.value;
  const { pairs, columns } = LEVELS[level];
  board.style.gridTemplateColumns = `repeat(${columns}, 1fr)`;
  createCards(pairs);
}

function createCards(pairs) {
  const images = [];
  for (let i = 1; i <= pairs; i++) images.push(`images/image${i}.jpg`);

  const allImages = [...images, ...images].sort(() => Math.random() - 0.5);
  board.innerHTML = '';

  allImages.forEach(img => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.innerHTML = `
      <div class="inner">
        <div class="face back">?</div>
        <div class="face front" style="background-image: url('${img}'); background-color: red;"></div>
      </div>
    `;
    card.addEventListener('click', () => flipCard(card, img));
    board.appendChild(card);
  });
}


function flipCard(card, image) {
  if (lock || card.classList.contains('flipped')) return;
  card.classList.add('flipped');

  if (!firstCard) firstCard = { card, image };
  else { secondCard = { card, image }; lock = true; checkMatch(); }
}

function checkMatch() {
  if (firstCard.image === secondCard.image) resetTurn(), checkWin();
  else setTimeout(() => {
    firstCard.card.classList.remove('flipped');
    secondCard.card.classList.remove('flipped');
    resetTurn();
  }, 900);
}

function resetTurn() { [firstCard, secondCard, lock] = [null, null, false]; }

function checkWin() {
  const totalCards = document.querySelectorAll('.card').length;
  const flippedCards = document.querySelectorAll('.flipped').length;
  if (flippedCards === totalCards) setTimeout(() => alert('🎉 Você ganhou!'), 400);
}

restartBtn.addEventListener('click', startGame);
levelSelect.addEventListener('change', startGame);
